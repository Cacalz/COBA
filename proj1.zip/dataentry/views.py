from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from .models import Project
from .forms import ProjectForm, FormDataLingkungan


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')  # nama URL ke dashboard kamu
        else:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

def dashboard_view(request):
    return render(request, 'dashboard.html')


def catatanpemeliharaan(request):
    return render(request, 'catatanpemeliharaan.html')

def simpan_project(request):
    if request.method == 'POST':
        nama_project = request.POST.get('nama_project')
        model = request.POST.get('model')
        deskripsi = request.POST.get('deskripsi')

        Project.objects.create(
            nama_project=nama_project,
            model=model,
            deskripsi=deskripsi
        )

        return redirect('/')  # Ganti ke halaman yang kamu inginkan setelah menyimpan
    return render(request, 'form_project.html')  # Ganti ke nama template HTML kamu


def project_form_view(request):
    form = ProjectForm()
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
    return render(request, 'project_form.html', {'form': form})

def project_form(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(' project/form/data_lingkungan.html')  
    else:
        form = ProjectForm()
    return render(request, 'project_form.html', {'form': form})

def data_lingkungan_Form(request):
    if request.method == 'POST':
        ...
    return render(request, 'data_lingkungan.html')

def data_lingkungan_view(request):
    if request.method == 'POST':
        # bisa proses data di sini
        return render(request, 'data_lingkungan.html')  # pastikan file ini ada!
    return render(request, 'data_lingkungan.html')  # fallback GET request


# new codes
def view_projek(request):
    form = ProjectForm()
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            projek = form.save()
            return redirect('view_data_lingkungan', id_projek = projek.id)
    context = {
        'form': form
    }
    return render(request, 'project_form.html', context)

def view_data_lingkungan(request, id_projek = None):
    projek = None
    if id_projek:
        projek = get_object_or_404(Project, id = id_projek)

    if request.method == 'POST':
        form = FormDataLingkungan(request.POST)
        if form.is_valid():
            data_lingkungan = form.save(commit=False)
            if projek:
                data_lingkungan.project = projek
            data_lingkungan.save()
            return redirect('view_data_lingkungan')
    else:
        form = FormDataLingkungan(initial={
            'project': projek
        } if projek else None )

    projeks = Project.objects.all()
    context = {
        'form': form,
        'projek': projeks,
        'pilih_projek': projek,
    }
    return render(request, 'data_lingkungan.html', context)
