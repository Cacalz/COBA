from django import forms
from .models import Project, DataLingkungan

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['nama_project', 'model', 'deskripsi']

class FormDataLingkungan(forms.ModelForm):
    class Meta:
        model = DataLingkungan
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)