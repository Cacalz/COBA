
from django.urls import path
from . import views

urlpatterns = [
    path('', views.login_view, name='login'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('catatanpemeliharaan/', views.catatanpemeliharaan, name='catatanpemeliharaan'),
    path('simpan_project/', views.simpan_project, name='simpan_project'),
    path('project/form/', views.project_form_view, name='project_form'),
    path('nested/', views.project_form_view, name='nested'),
    path('kinerja', views.project_form_view, name='kinerja'),


    path('projek/form/', views.view_projek, name='projek'),
    path('projek/form/data_lingkungan/', views.view_data_lingkungan, name='data_lingkungan'),
    path('projek/form/data_lingkungan/<int:id_projek>', views.view_data_lingkungan, name='data_lingkungan'),
]